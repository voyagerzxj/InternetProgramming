package cn.bukaa.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bukaa.dao.CommDAO;
import cn.bukaa.util.Info;

public class UserController extends MainCtrl {

	private CommDAO dao;
	//do diffrenct job according to the attributes
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		dao = new CommDAO();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String ac = request.getParameter("ac");
		String date = Info.getDateStr();
		String today = date.substring(0, 10);
		String tomonth = date.substring(0, 7);
		if ("login".equals(ac)) {
			try {
				login(request, response);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("logout".equals(ac)){
			logout(request,response);
		}
		else if("uppass".equals(ac)){
			
			
			
			String clientadd = request.getRemoteAddr();
			String serveradd = InetAddress.getLocalHost().getHostAddress();
			if(clientadd.equals(serveradd)) {updatePass(request, response);}
			else{request.setAttribute("error", "");
			     go("/admin/uppass.jsp", request, response);}
		}
		
	}
	//handle logout request
	private void logout(HttpServletRequest request,HttpServletResponse response) {
		request.getSession().invalidate();
		gor("login.jsp", request, response);
		
	}
	//handle login request
	private void login(HttpServletRequest request, HttpServletResponse response) throws Throwable{
		String pagerandom = request.getParameter("pagerandom") == null ? ""
				: request.getParameter("pagerandom");
		String random = (String) request.getSession()
				.getAttribute("random");

		
		if (!pagerandom.equals(random) && request.getParameter("a") != null) {
			request.setAttribute("random", "");
			go("/login.jsp", request, response);
		} else {
			dao = new CommDAO();
			String username = request.getParameter("uname");
			String password = request.getParameter("upass");
			String utype = request.getParameter("utype");
			request.getSession().setAttribute("utype", utype);
//			List<HashMap> list = dao
//					.select("select * from sysuser where binary uname='"
//							+ username + "'");
			String select_str1 = "select * from sysuser where binary uname=?";
			PreparedStatement select_statement1 = dao.getConn().prepareStatement(select_str1);
			select_statement1.setString(1,username);
			ResultSet rs = select_statement1.executeQuery();
			List<HashMap> list = resultSetToList(rs);
			rs.close();
			select_statement1.close();
			if (list.size() == 1) {
				HashMap map = list.get(0);
//				List<HashMap> ulist = dao
//						.select("select * from sysuser where binary uname='"
//								+ username + "' and upass='" + password
//								+ "'");
				String select_str2 = "select * from sysuser where binary uname=? and upass = ?";
			    PreparedStatement select_statement2 = dao.getConn().prepareStatement(select_str2);
			    select_statement2.setString(1,username);
			    select_statement2.setString(2,password);
			    ResultSet rs2 = select_statement2.executeQuery();
				List<HashMap> ulist = resultSetToList(rs2);
				rs2.close();
				select_statement2.close();
				if (ulist.size() == 1
						&& password.equals(map.get("upass").toString())) {

					request.getSession().setAttribute("admin", map);
					dao = new CommDAO();
					HashMap<String,Object> ext = new HashMap<String,Object>();
					ext.put("userid", map.get("id"));
					ext.put("tname", map.get("tname"));
					ext.put("oper", "Login");
					request.setAttribute("f", "f");
					
		
					
					
					
					//response.setHeader("Set-Cookie", "key=value;SameSite=strict");
					dao.insert(request, response, "log", ext, false, true);
					gor("admin/index.jsp", request, response);

				} else {
					request.setAttribute("error", "");
					go("/login.jsp", request, response);
				}
			} else {
				request.setAttribute("error", "");
				go("/login.jsp", request, response);
			}
		}

	}
	//Update password
	private void  updatePass(HttpServletRequest request, HttpServletResponse response){
		dao = new CommDAO();
		String olduserpass = request.getParameter("oldpass");
		String userpass = request.getParameter("upass");
		String copyuserpass = request.getParameter("repass");
		HashMap user = dao.getmap(Info.getUser(request).get("id")
				.toString(), "sysuser");
		if (!(((String) user.get("upass")).equals(olduserpass))) {
			request.setAttribute("error", "");
			go("/admin/uppass.jsp", request, response);
		} else {
			String id = (String) user.get("id");
			String sql = "update sysuser set upass='" + userpass
					+ "' where id=" + id;
			dao.commOper(sql);
			request.setAttribute("suc", "");
			go("/admin/uppass.jsp", request, response);
		}
	}

	private List<HashMap> resultSetToList(ResultSet rs) {
		List<HashMap> list = new ArrayList();
		try {
			ResultSetMetaData rsmd = rs.getMetaData();
			while(rs.next())
		    {
		    	HashMap map = new HashMap();
		    	int i = rsmd.getColumnCount();
		    	for(int j=1;j<=i;j++)
		    	{
		    		if(!rsmd.getColumnName(j).equals("ID"))
		    		{
		    			String str = rs.getString(j)==null?"": rs.getString(j);
		    			if(str.equals("null"))str = "";
		    			map.put(rsmd.getColumnName(j), str);
		    		}
		    		else
		    			map.put("id", rs.getString(j));
		    	}
		    	list.add(map);
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
