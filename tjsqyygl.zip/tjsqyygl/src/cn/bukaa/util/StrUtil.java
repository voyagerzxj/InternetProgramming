package cn.bukaa.util;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**Some utilities to manipulate strings.


*/

public class StrUtil {
	private static int idSequence=10000;
	
	//This function is for converting the raw string password to hashed string via SHA-256 hash function
	String passwordToHash(String passwd) {
		  MessageDigest md;
		  try {
		   md = MessageDigest.getInstance("SHA-256");
		   md.update(passwd.getBytes());
		   byte[] hash = md.digest();
		   return byte2Str(hash);
		  } catch (NoSuchAlgorithmException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }
		  return new String("");
		 }
		 
		 String byte2Str(byte[] hash) {
		  StringBuilder sb = new StringBuilder();
		  for(byte bt : hash) {
		   //System.out.println((int)bt + " " + ((bt&0xf0)>>4) + " " + (bt&0xf));
		   sb.append((char)('a'+((bt&0xf0)>>4)));
		   sb.append((char)('a'+(bt&0xf)));
		  }
		  return sb.toString();
		 }
	
	public static String checkStr(Object obj) {
		if(obj==null){
			return "";
		}else{
			return obj.toString();
		}		
	}
	/**
	 * Generate id
	 * @return
	 */
	
	public synchronized static String generalSrid() {
		StringBuffer ret = new StringBuffer(20);		
		ret.append(StrUtil.getFormatDate("yyyyMMddHHmmss"));		
		idSequence++;
		if(idSequence>20000)
		  idSequence-=10000;
		ret.append(String.valueOf(idSequence).substring(1));
		return ret.toString();
	}
	public static String generalFileName(String srcFileName) {
		try{
		   int index=srcFileName.lastIndexOf(".");
		   return StrUtil.generalSrid()+srcFileName.substring(index).toLowerCase();
		}catch(Exception e){
			return StrUtil.generalSrid();
		}
	}
	public static String parseOS(String agent) {
		
		String system="Other";
		if(agent.indexOf("Windows")!=-1) 
			system="Windows";
		else if(agent.indexOf("unix")!=-1) 
			system="unix";
		else if(agent.indexOf("SunOS")!=-1) 
			system="SunOS";
		else if(agent.indexOf("BSD")!=-1) 
			system="BSD";
		else if(agent.indexOf("linux")!=-1) 
			system="linux";
		else if(agent.indexOf("Mac")!=-1) 
			system="Mac";
		else
			system = "Other";		
	    return system;
	}
	
	/**
	 * Get formatted string of current date
	 * 
	 * @param formatString
	 * eg:yyyy(y)-MM(m)-dd(d)-HH(h)-mm(m)-ss(s)-SSS(ms)
	
	 * @return formatted string of current date
	 */
	public static String getFormatDate(String formatString) {
		Date now =new Date(System.currentTimeMillis());
		SimpleDateFormat sdf=new SimpleDateFormat(formatString);
		String ret=sdf.format(now);
		return ret;
	}	
	/**
	 * @param no
	 * @return current date
	 */
	public static Date getCurrentDate() {
		Date now =new Date(System.currentTimeMillis());
		return now;
	}
	/**
	 * Convert formatted string into date
	 * 
	 * @param formatString
	 * eg:yyyy(y)-MM(m)-dd(d)-HH(h)-mm(m)-ss(s)-SSS(ms)
	
	 * @return date
	 */
	public static Date formatDate(String dateString) {
		try {
			SimpleDateFormat sdf=new SimpleDateFormat();	
			Date date=sdf.parse(dateString);
			return date;
		} catch (ParseException e) {			
			return new Date();
		}		
	}
	
	public static int parseInt(String numberStr) {
		//Pattern pattern=Pattern.compile("[0-9]*");
		//Pattern pattern=Pattern.compile("^[\\-\\d][0-9]*[\\.]{0,1}[0-9]+$");
		if(numberStr==null)
			return 0;
		Pattern pattern=Pattern.compile("^[\\-]{0,1}[0-9]+$");
		Matcher matcher = pattern.matcher(numberStr);
		if(matcher.find()){
			return Integer.parseInt(numberStr);
		}else{
			return 0;
		}			
	}
   
}
