package cn.bukaa.util;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * Use c3p0-copnfig.xml file
 */
public class JdbcUtils {
	// EagerSingleton
	private static DataSource ds = new ComboPooledDataSource();
	
	/**
	 * null: no transaction
	 * not null: has transaction
	 * when starting transaction, pass value
	 * when transaction ends，set it to null
	 * when starting transaction,  make multiple methods in dao share this Connection
	 */
	private static ThreadLocal<Connection> tl = new ThreadLocal<Connection>();
	
	public static DataSource getDataSource() {
		return ds;
	}
	
	/**
	 * dao uses this function to get data
	 * @return
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		/*
		 * when there's transaction, return current transaction's con
		 * when there's no transaction, return new con via connection pool
		 */
		Connection con = tl.get();//get current transaction' con
		if(con != null) return con;
		return ds.getConnection();
	}
	
	/**
	 * start transaction
	 * @throws SQLException 
	 */
	public static void beginTransaction() throws SQLException {
		Connection con = tl.get();//get current transaction' con
		if(con != null) throw new SQLException("Transaction already began, can't be restarted");
		con = ds.getConnection();//set con
		con.setAutoCommit(false);//set to manual submission
		tl.set(con);
	}
	
	/**
	 * commit transaction
	 * @throws SQLException 
	 */
	public static void commitTransaction() throws SQLException {
		Connection con = tl.get();//get current transaction' con
		if(con == null) throw new SQLException("No transaction to submit！");
		con.commit();//commit transaction
		con.close();//close connection
		con = null;//tranaction ends
		tl.remove();
	}
	
	/**
	 * rollback transaction
	 * @throws SQLException 
	 */
	public static void rollbackTransaction() throws SQLException {
		Connection con = tl.get();//get current transaction' con
		if(con == null) throw new SQLException("No transaction, can't roll back!");
		con.rollback();
		con.close();
		con = null;
		tl.remove();
	}
	
	/**
	 * release Connection
	 * @param con
	 * @throws SQLException 
	 */
	public static void releaseConnection(Connection connection) throws SQLException {
		Connection con = tl.get();//get current transaction' con
		if(connection != con) {//close connection if not current transaction
			if(connection != null &&!connection.isClosed()) {//close connection
				connection.close();
			}
		}
	}
}
